﻿INSERT INTO Minions (Name, Age, TownId)
VALUES (@name, @age, @townId)