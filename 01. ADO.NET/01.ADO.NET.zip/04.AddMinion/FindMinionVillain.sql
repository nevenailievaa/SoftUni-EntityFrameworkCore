﻿SELECT COUNT(*) AS Count
FROM MinionsVillains
WHERE MinionId = @minionId AND VillainId = @villainId