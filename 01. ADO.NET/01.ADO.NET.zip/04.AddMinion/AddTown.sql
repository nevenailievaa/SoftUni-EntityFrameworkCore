﻿INSERT INTO Towns (Name, CountryName)
VALUES (@name, NULL)