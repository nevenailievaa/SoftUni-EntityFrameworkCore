﻿SELECT Id FROM Minions
WHERE Name = @name