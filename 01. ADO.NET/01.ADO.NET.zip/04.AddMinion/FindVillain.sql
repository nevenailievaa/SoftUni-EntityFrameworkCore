﻿SELECT Id FROM Villains
WHERE Name = @name