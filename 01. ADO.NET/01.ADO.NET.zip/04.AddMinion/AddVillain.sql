﻿INSERT INTO Villains (Name, EvilnessFactor)
VALUES (@name, 'evil')