﻿SELECT Id FROM Towns
WHERE Name = @name