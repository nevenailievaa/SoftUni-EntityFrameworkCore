﻿INSERT INTO MinionsVillains (MinionId, VillainId)
VALUES (@minionId, @villainId)