﻿DELETE FROM Villains
WHERE Id = @villainId