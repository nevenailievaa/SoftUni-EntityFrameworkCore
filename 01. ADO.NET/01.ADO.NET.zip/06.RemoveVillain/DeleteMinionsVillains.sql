﻿DELETE FROM MinionsVillains
WHERE VillainId = @villainId