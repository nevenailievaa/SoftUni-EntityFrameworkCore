﻿UPDATE Minions
SET Age += 1, Name = @name
WHERE Id = @id