﻿SELECT Name FROM Minions
WHERE Id = @id