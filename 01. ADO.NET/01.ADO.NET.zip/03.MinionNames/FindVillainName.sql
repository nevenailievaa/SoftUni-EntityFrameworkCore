﻿SELECT Name FROM Villains
WHERE Id = @villainId