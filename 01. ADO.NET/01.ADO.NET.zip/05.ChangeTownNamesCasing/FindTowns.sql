﻿SELECT Name FROM Towns
WHERE CountryName = @countryName