﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-140PNU1\SQLEXPRESS;Database=Cadastre;Integrated Security=True;Encrypt=False";
    }
}
